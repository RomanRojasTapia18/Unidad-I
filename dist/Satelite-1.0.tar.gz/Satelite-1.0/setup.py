from setuptools import setup

setup(
    name='Satelite',
    version=1.0,
    description='This module calculate Orbit ',
    author='Roman',
    author_email='romanrojastapia@gmail.com',
    url='http://www.utng.edu.mx',
    py_modules=['Satelite']
)